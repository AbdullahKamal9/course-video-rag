import os
import requests
import chromadb
from sentence_transformers import SentenceTransformer


def get_groq_api_key():
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("Please set the GROQ_API_KEY environment variable before running this script.")
    return api_key


def create_embedding(text_list):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    return model.encode(text_list).tolist()


def inference(prompt):
    from groq import Groq
    client_groq = Groq(api_key=get_groq_api_key())
    message = client_groq.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[
            {"role": "user", "content": prompt}
        ],
        max_tokens=512,
    )
    return message.choices[0].message.content


def build_prompt(chunks, incoming_query):
    chunk_records = []
    for metadata, text in chunks:
        chunk_records.append(
            f"Video title: {metadata.get('title')} | number: {metadata.get('number')} | start: {metadata.get('start')} | end: {metadata.get('end')} | text: {text}"
        )

    chunk_json = "\n".join(chunk_records)
    return f'''I am teaching web development in my Sigma web development course. Here are video subtitle chunks containing video title, video number, start time in seconds, end time in seconds, and the text at that time:\n\n{chunk_json}\n---------------------------------\n"{incoming_query}"\nUser asked this question related to the video chunks, you have to answer in a human way (dont mention the above format, its just for you) where and how much content is taught in which video (in which video and at what timestamp) and guide the user to go to that particular video. If user asks unrelated question, tell him that you can only answer questions related to the course.'''


if __name__ == "__main__":
    client = chromadb.PersistentClient(path="chroma_db")
    collection = client.get_collection("rag_course")
    if collection is None:
        raise RuntimeError("Chroma collection 'rag_course' not found. Run preprocess_json.py first.")

    incoming_query = input("Ask a Question: ")
    question_embedding = create_embedding([incoming_query])[0]

    results = collection.query(
        query_embeddings=[question_embedding],
        n_results=5,
        include=["metadatas", "documents"],
    )

    chunks = []
    for metadata, document in zip(results["metadatas"][0], results["documents"][0]):
        chunks.append((metadata, document))

    prompt = build_prompt(chunks, incoming_query)
    with open("prompt.txt", "w", encoding="utf-8") as f:
        f.write(prompt)

    response = inference(prompt)
    print(response)

    with open("response.txt", "w", encoding="utf-8") as f:
        f.write(response)
