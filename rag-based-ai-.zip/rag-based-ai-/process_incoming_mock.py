"""
Mock version of process_incoming.py for testing without Groq API key.
Shows retrieved chunks and simulates LLM response.
"""
import chromadb
from sentence_transformers import SentenceTransformer


def create_embedding(text_list):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    return model.encode(text_list).tolist()


def build_prompt(chunks, incoming_query):
    chunk_records = []
    for metadata, text in chunks:
        chunk_records.append(
            f"Video title: {metadata.get('title')} | number: {metadata.get('number')} | start: {metadata.get('start')} | end: {metadata.get('end')} | text: {text}"
        )

    chunk_json = "\n".join(chunk_records)
    return f'''I am teaching web development in my Sigma web development course. Here are video subtitle chunks containing video title, video number, start time in seconds, end time in seconds, and the text at that time:\n\n{chunk_json}\n---------------------------------\n"{incoming_query}"\nUser asked this question related to the video chunks, you have to answer in a human way (dont mention the above format, its just for you) where and how much content is taught in which video (in which video and at what timestamp) and guide the user to go to that particular video. If user asks unrelated question, tell him that you can only answer questions related to the course.'''


def mock_inference(prompt, chunks):
    """Generate contextual LLM-like response from retrieved chunks."""
    if not chunks:
        return "I don't have relevant information to answer this question. Please ask a question related to the course content."
    
    # Extract actual text content and metadata
    text_snippets = [text[:200] for _, text in chunks]
    
    # Extract unique videos with timestamps
    videos = {}
    for metadata, text in chunks:
        title = metadata.get('title', 'Unknown')
        number = metadata.get('number', '?')
        start = metadata.get('start', 0)
        if number not in videos:
            videos[number] = {'title': title, 'start': start}
    
    response = f"""Based on the retrieved course materials:\n\n"""
    
    # Add synthesized answer from chunks
    response += f"**Key information from course:\n**"
    for snippet in text_snippets[:2]:
        response += f"- {snippet}\n"
    
    response += f"\n**Where to learn more:**\n"
    for number in sorted(videos.keys(), key=lambda x: int(x) if str(x).isdigit() else 0):
        info = videos[number]
        response += f"📹 Video {number}: **{info['title']}** (around {int(float(info['start']))}s)\n"
    
    return response


if __name__ == "__main__":
    client = chromadb.PersistentClient(path="chroma_db")
    collection = client.get_collection("rag_course")
    if collection is None:
        raise RuntimeError("Chroma collection 'rag_course' not found. Run preprocess_json.py first.")

    incoming_query = input("Ask a Question: ")
    question_embedding = create_embedding([incoming_query])[0]

    results = collection.query(
        query_embeddings=[question_embedding],
        n_results=5,
        include=["metadatas", "documents"],
    )

    chunks = []
    for metadata, document in zip(results["metadatas"][0], results["documents"][0]):
        chunks.append((metadata, document))

    prompt = build_prompt(chunks, incoming_query)
    with open("prompt.txt", "w", encoding="utf-8") as f:
        f.write(prompt)

    print("\n" + "="*60)
    print("RETRIEVED CHUNKS FROM DATABASE:")
    print("="*60)
    for i, (metadata, text) in enumerate(chunks, 1):
        print(f"\n[{i}] Video: {metadata.get('title')} (Video #{metadata.get('number')})")
        print(f"    Time: {metadata.get('start')}s - {metadata.get('end')}s")
        print(f"    Text: {text[:100]}..." if len(text) > 100 else f"    Text: {text}")

    print("\n" + "="*60)
    print("LLM RESPONSE (Mock - based on retrieved chunks):")
    print("="*60)
    response = mock_inference(prompt, chunks)
    print(response)

    with open("response.txt", "w", encoding="utf-8") as f:
        f.write(response)
    
    print("\n" + "="*60)
    print("✓ Prompt saved to 'prompt.txt'")
    print("✓ Response saved to 'response.txt'")
