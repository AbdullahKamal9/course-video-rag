import json
import os
import chromadb
from sentence_transformers import SentenceTransformer


def combine_chunks(chunks, chunk_size=5):
    """
    Combine small chunks into larger, more meaningful segments.
    chunk_size: number of small chunks to combine (default 5 = ~15-25 seconds of content)
    """
    combined = []
    for i in range(0, len(chunks), chunk_size):
        group = chunks[i:i+chunk_size]
        if not group:
            continue
            
        combined_text = " ".join([c["text"] for c in group])
        combined_chunk = {
            "text": combined_text,
            "title": group[0].get("title"),
            "number": group[0].get("number"),
            "start": group[0].get("start"),
            "end": group[-1].get("end"),
        }
        combined.append(combined_chunk)
    return combined


if __name__ == "__main__":
    model = SentenceTransformer('all-MiniLM-L6-v2')
    client = chromadb.PersistentClient(path="chroma_db")
    collection = client.get_or_create_collection("rag_course")

    jsons = sorted(os.listdir("jsons"))
    for json_file in jsons:
        with open(os.path.join("jsons", json_file), "r", encoding="utf-8") as f:
            content = json.load(f)

        # Combine small chunks into larger segments (5 chunks = ~15-25 seconds)
        combined_chunks = combine_chunks(content["chunks"], chunk_size=5)
        
        texts = [chunk["text"] for chunk in combined_chunks]
        print(f"Creating embeddings for {json_file} ({len(combined_chunks)} combined chunks from {len(content['chunks'])} original)")
        embeddings = model.encode(texts).tolist()

        ids = [f"{os.path.splitext(json_file)[0]}-{i}" for i in range(len(combined_chunks))]
        metadatas = [
            {
                "title": chunk.get("title"),
                "number": chunk.get("number"),
                "start": chunk.get("start"),
                "end": chunk.get("end"),
                "source": json_file,
            }
            for chunk in combined_chunks
        ]

        collection.add(
            ids=ids,
            documents=texts,
            metadatas=metadatas,
            embeddings=embeddings,
        )

    print(f"Saved vectors to Chroma at 'chroma_db'")

